function sendMessage(e) {
  e.preventDefault();
  document.getElementById('response').innerText = 'Pesan berhasil dikirim! Terima kasih telah menghubungi saya.';
  document.querySelector('form').reset();
}